<?php session_start(); ?>
<?php header('Location: login2.php');?>
